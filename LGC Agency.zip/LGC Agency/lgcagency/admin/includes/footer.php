<div class="copyrights">
	 <p>© 2020 LGC. All Rights Reserved |  <a href="#">LGC</a> </p>
</div>	
